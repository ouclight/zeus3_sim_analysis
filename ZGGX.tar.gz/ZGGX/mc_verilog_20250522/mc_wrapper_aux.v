module mc_wrapper_aux #(
                parameter    APB_DATA_WIDTH       = 32,
                parameter    APB_ADDR_WIDTH       = 11,
                parameter    ARRAY_DATA_WIDTH     = 256,
                parameter    ARRAY_ROW_ADDR_WIDTH = 13,
                parameter    ARRAY_COL_ADDR_WIDTH = 8,
                parameter    CHECKBIT_WIDTH       = 10,
                parameter    PATTERN_WIDTH        = 32,
                parameter    CSL_ERR_TH_WIDTH     = 5,
                parameter    HUB_FRAME_WIDTH      = ARRAY_DATA_WIDTH+CHECKBIT_WIDTH+ARRAY_ROW_ADDR_WIDTH+ARRAY_COL_ADDR_WIDTH+3+1
        )(
                input                                                  clk                 ,
                input                                                  rst_n               ,
                input                                                  ras_clr             ,
                input    [31:0]                                        mc_id_soc           ,
                input    [31:0]                                        mc_id_pe            ,

                input                                                  mc_rf_start         ,
                input                                                  global_rf_sel_en    , 
                input                                                  global_rf_sel       ,
                input                                                  global_mc_bist_start,//pulse signal
                input                                                  global_mc_bist_en   ,
                input                                                  global_mc_rescan_start ,//default 0,pulse signal
                input    [4:0]                                         global_dram_init_en ,//[0]:dram_init_en,[1]:rf_cnt_clr,clear rf_cnt,[4:2]:reserved
                input                                                  global_bist_clr     ,//pulse signal
                input    [3:0]                                         bist_rescan_num     ,//default 3,max 8
                input                                                  mc_scan_timeout_en  ,//initial scan timeout en
                input                                                  mc_bist_csl_vmc_en  ,

                input                                                  rf_range_change_en  ,
                input                                                  pre_precharge       ,
                input                                                  page_mode_switch    ,
                input    [ARRAY_ROW_ADDR_WIDTH*2-1:0]                  rf_addr             ,//{rf_start_addr,rf_end_addr}

                input                                                  dbg_data_store_en   ,//dbg function, store latest frame and rdata 
                //apb bus
                input                                                  apb_clk             ,
                input                                                  apb_rst_n           ,
                //pe apb bus
                input                                                  pe_apb_sel          ,
                input                                                  pe_apb_enable       ,
                input                                                  pe_apb_write        ,
                input    [APB_ADDR_WIDTH-1:0]                          pe_apb_addr         ,
                input    [APB_DATA_WIDTH-1:0]                          pe_apb_wdata        ,
                output   [APB_DATA_WIDTH-1:0]                          pe_apb_rdata        ,
                output                                                 pe_apb_pslverr      ,
                //soc apb bus
                input                                                  soc_apb_sel         ,
                input                                                  soc_apb_enable      ,
                input                                                  soc_apb_write       ,
                input    [APB_ADDR_WIDTH-1:0]                          soc_apb_addr        ,
                input    [APB_DATA_WIDTH-1:0]                          soc_apb_wdata       ,
                output   [APB_DATA_WIDTH-1:0]                          soc_apb_rdata       ,
                output                                                 soc_apb_pslverr     ,


                //array interface
                output                                                 bnksel_n            , 
                output   [ARRAY_ROW_ADDR_WIDTH-1:0]                    gradd_n             ,
                output                                                 gcas_wr             ,
                output                                                 gcas_rd             ,
                output   [ARRAY_COL_ADDR_WIDTH-1:0]                    gcadd               ,
                //output                                                 wrrdy_n             ,
                output   [ARRAY_DATA_WIDTH+CHECKBIT_WIDTH-1:0]         wdl                 ,
                output                                                 wdl_oe              ,
                input                                                  rdrdy_n             ,
                input    [ARRAY_DATA_WIDTH+CHECKBIT_WIDTH-1:0]         rdl                 ,
                //hub to mc frame
                input                                                  hub_frame_vld       ,
                output                                                 hub_frame_rdy       ,
                input    [HUB_FRAME_WIDTH-2:0]                         hub_frame_data      ,//msb wstrb flag
                //bresp
                input                                                  mc_bresp_rdy        ,
                output reg  [1:0]                                      mc_bresp            ,
                output reg                                             mc_bresp_vld        ,
                //array read data
                output                                                 mc_rvalid           ,
                output   [ARRAY_DATA_WIDTH+CHECKBIT_WIDTH-1:0]         mc_rdata            ,
                //phy timing cfg
                output   [3:0]                                         bank_radd_set_time_o,
                output   [3:0]                                         cadd_set_time_o     ,
                output   [7:0]                                         r_cas_set_time_o    ,
                output   [7:0]                                         w_cas_set_time_o    ,
                output   [7:0]                                         cas_wrrdy_time_o    ,
                //array timing cfg
                input    [5:0]                                         mc_trc_cfg          ,//active to active time
                input    [4:0]                                         mc_tras_cfg         ,//rcd active to precharge time
                input    [3:0]                                         mc_trp_cfg          ,//precharge time
                input    [4:0]                                         mc_trcd_cfg         ,//write rcd time
                input    [0:0]                                         mc_trtp_cfg         ,//rd cas rising edge to precharge time
                input    [3:0]                                         mc_twr_cfg          ,//wr cas falling edge to precharge time
                input    [2:0]                                         mc_twtr_cfg         ,//write cas To Read cas time
                input    [3:0]                                         mc_trtw_cfg         ,//Read cas To Write cas time

                //bist pattern
                input    [PATTERN_WIDTH-1:0]                           bist_pattern0       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern1       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern2       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern3       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern4       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern5       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern6       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern7       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern8       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern9       ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern10      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern11      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern12      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern13      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern14      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern15      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern16      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern17      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern18      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern19      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern20      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern21      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern22      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern23      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern24      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern25      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern26      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern27      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern28      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern29      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern30      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern31      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern32      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern33      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern34      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern35      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern36      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern37      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern38      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern39      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern40      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern41      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern42      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern43      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern44      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern45      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern46      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern47      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern48      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern49      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern50      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern51      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern52      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern53      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern54      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern55      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern56      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern57      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern58      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern59      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern60      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern61      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern62      ,
                input    [PATTERN_WIDTH-1:0]                           bist_pattern63      ,
                input    [6:0]                                         bist_csl_scan_num   ,
                input    [6:0]                                         bist_wl_scan_num    ,
                input    [CSL_ERR_TH_WIDTH-1:0]                        csl_err_threshold   ,
                input    [3:0]                                         bist_wl_scan_single_pattern_rd_num,
                output                                                 bist_rescan_success ,
                output                                                 bist_rescan_finish  ,
                //timeout
                input    [31:0]                                        mc_timeout_th       ,
                //stc ctrl
                input                                                  mc_rf_start_sel     ,//0:sel input rf start,1:sel mc local cfg
                input    [31:0]                                        rf_start_time       ,//dap_aux cfg rf start time
                input    [31:0]                                        rf_period           ,//dap_aux sel
                input                                                  rf_period_up_en     ,//pulse signal
                input                                                  mc_rf_period_sel    ,//0:sel input rf period,1:sel mc local,default 0
                //rst release rst
                output                                                 mc_sys_rst_n        ,
                output                                                 mc_apb_rst_n        , 
                //intrupt
                output                                                 bist_finish_intr    ,
                output                                                 mc_timeout_intr     ,
                //bist success
                output                                                 mc_bank_success     ,
                //monitor
                output   [99:0]                                        monitor_signals     

    );
wire                                             mc_debug_en         ;
wire                                             mc_frame_vld        ;
wire                                             mc_frame_rdy        ;
wire     [HUB_FRAME_WIDTH-2:0]                   mc_frame_data       ;
wire                                             mc_back_rvalid      ;
wire     [ARRAY_DATA_WIDTH+CHECKBIT_WIDTH-1:0]   mc_back_rdata       ;
wire                                             rst_mc_n            ;
wire                                             presetn             ;
wire                                             bank_success        ;
//wire                                             bist_rescan_finish  ;
wire                                             bist_finish_int     ;
wire                                             rescan_finish_intr  ;

//-----------------------------reset release------------------------------------
wl_dft_rst_sync_aux u_rst_mc_n(
    .clk_i       (clk),
    .rst_n_i     (rst_n),
    .dft_mode_i  (1'b0),
    .dft_rst_n_i (1'b1),
    .rst_n_sync_o(rst_mc_n)
);
wl_dft_rst_sync_aux u_rst_apb_n(
    .clk_i       (apb_clk),
    .rst_n_i     (apb_rst_n),
    .dft_mode_i  (1'b0),
    .dft_rst_n_i (1'b1),
    .rst_n_sync_o(presetn)
);

assign mc_sys_rst_n     = rst_mc_n;
assign mc_apb_rst_n     = presetn;
assign mc_bank_success  = bank_success ;
assign bist_finish_intr = rescan_finish_intr | bist_finish_int ;

mc_frame_debug_aux #(
                .HUB_FRAME_WIDTH   (HUB_FRAME_WIDTH-1),
                .ARRAY_DATA_WIDTH  (ARRAY_DATA_WIDTH+CHECKBIT_WIDTH)
)mc_frame_debug_u
(
                .clk           (clk             ),
                .rst_n         (rst_mc_n        ),
                .mc_debug_en   (mc_debug_en     ),
                .hub_frame_vld (hub_frame_vld   ),
                .hub_frame_rdy (hub_frame_rdy   ),
                .hub_frame_data(hub_frame_data  ),
                .mc_frame_vld  (mc_frame_vld    ),
                .mc_frame_rdy  (mc_frame_rdy    ),
                .mc_frame_data (mc_frame_data   ),
                .mc_back_rvalid(mc_back_rvalid  ),
                .mc_back_rdata (mc_back_rdata   ),
                .mc_rvalid     (mc_rvalid       ),
                .mc_rdata      (mc_rdata        )
    );



////--------------------------generate bresponse---------------------------////

always @(posedge clk or negedge rst_mc_n)begin
    if(!rst_mc_n)begin
        mc_bresp_vld <= 1'b0;
        mc_bresp <= 2'b00;
    end
    else if (hub_frame_vld && hub_frame_rdy && hub_frame_data[HUB_FRAME_WIDTH-3])begin
        mc_bresp_vld <= 1'b1;
        mc_bresp <= 2'b00;
    end
    else begin
        mc_bresp_vld <= 1'b0;
        mc_bresp <= 2'b00;
    end
end


mc_top_aux #(
               .APB_DATA_WIDTH       (APB_DATA_WIDTH        ),
               .APB_ADDR_WIDTH       (APB_ADDR_WIDTH        ),
               .ARRAY_DATA_WIDTH     (ARRAY_DATA_WIDTH      ),
               .ARRAY_ROW_ADDR_WIDTH (ARRAY_ROW_ADDR_WIDTH  ),
               .ARRAY_COL_ADDR_WIDTH (ARRAY_COL_ADDR_WIDTH  ),
               .PATTERN_WIDTH        (PATTERN_WIDTH         ),
               .CSL_ERR_TH_WIDTH     (CSL_ERR_TH_WIDTH      ),
               .CHECKBIT_WIDTH       (CHECKBIT_WIDTH        ),
               .FRAME_WIDTH          (HUB_FRAME_WIDTH       )
)mc_top_u(

                .clk                 (clk                  ),
                .rst_n               (rst_mc_n             ),
                .mc_id_soc           (mc_id_soc            ),
                .mc_id_pe            (mc_id_pe             ),
                .ras_clr             (ras_clr              ),

                .mc_rf_start         (mc_rf_start          ),
                .global_rf_sel_en    (global_rf_sel_en     ), 
                .global_rf_sel       (global_rf_sel        ),
                .global_mc_bist_start(global_mc_bist_start ),
                .global_mc_bist_en   (global_mc_bist_en    ),
                .global_mc_rescan_start (global_mc_rescan_start),
                .global_dram_init_en (global_dram_init_en[0]),
                .global_rf_cnt_clr   (global_dram_init_en[1]),//clear rf_cnt,default 0
                .global_bist_clr     (global_bist_clr      ),
                .mc_bist_csl_vmc_en  (mc_bist_csl_vmc_en   ),
                .bist_rescan_num     (bist_rescan_num      ),
                .bist_rescan_success (bist_rescan_success  ),
                .bist_rescan_finish  (rescan_finish_intr   ),
                .bist_rescan_finish_status(bist_rescan_finish),
                //.mc_dram_init_finish (mc_dram_init_finish  ),

                .mc_debug_en         (mc_debug_en          ),
                .mc_scan_timeout_en  (mc_scan_timeout_en   ),
                .bist_finish_int     (bist_finish_int      ),
                .rf_range_change_en  (rf_range_change_en   ),
                .pre_precharge       (pre_precharge        ),
                .page_mode_switch    (page_mode_switch     ),
                .rf_addr             (rf_addr              ),
                .dbg_data_store_en   (dbg_data_store_en    ),
                
                .apb_clk             (apb_clk              ),
                .apb_rst_n           (presetn              ),
                
                .pe_apb_sel          (pe_apb_sel           ),
                .pe_apb_enable       (pe_apb_enable        ),
                .pe_apb_write        (pe_apb_write         ),
                .pe_apb_addr         (pe_apb_addr          ),
                .pe_apb_wdata        (pe_apb_wdata         ),
                .pe_apb_rdata        (pe_apb_rdata         ),
                
                .soc_apb_sel         (soc_apb_sel          ),
                .soc_apb_enable      (soc_apb_enable       ),
                .soc_apb_write       (soc_apb_write        ),
                .soc_apb_addr        (soc_apb_addr         ),
                .soc_apb_wdata       (soc_apb_wdata        ),
                .soc_apb_rdata       (soc_apb_rdata        ),

                .mc_tras_cfg         (mc_tras_cfg          ),//rcd active to precharge time
                .mc_trp_cfg          (mc_trp_cfg           ),//precharge time
                .mc_trc_cfg          (mc_trc_cfg           ),//active to active time
                .mc_trcd_cfg         (mc_trcd_cfg          ),//read rcd time
                .mc_trtp_cfg         (mc_trtp_cfg          ),//rd cas rising edge to precharge time
                .mc_twr_cfg          (mc_twr_cfg           ),//wr cas falling edge to precharge time
                .mc_twtr_cfg         (mc_twtr_cfg          ),//write cas To Read cas time
                .mc_trtw_cfg         (mc_trtw_cfg          ),//Read cas To Write cas time

                .bist_pattern0       (bist_pattern0        ),
                .bist_pattern1       (bist_pattern1        ),
                .bist_pattern2       (bist_pattern2        ),
                .bist_pattern3       (bist_pattern3        ),
                .bist_pattern4       (bist_pattern4        ),
                .bist_pattern5       (bist_pattern5        ),
                .bist_pattern6       (bist_pattern6        ),
                .bist_pattern7       (bist_pattern7        ),
                .bist_pattern8       (bist_pattern8        ),
                .bist_pattern9       (bist_pattern9        ),
                .bist_pattern10      (bist_pattern10       ),
                .bist_pattern11      (bist_pattern11       ),
                .bist_pattern12      (bist_pattern12       ),
                .bist_pattern13      (bist_pattern13       ),
                .bist_pattern14      (bist_pattern14       ),
                .bist_pattern15      (bist_pattern15       ),
                .bist_pattern16      (bist_pattern16       ),
                .bist_pattern17      (bist_pattern17       ),
                .bist_pattern18      (bist_pattern18       ),
                .bist_pattern19      (bist_pattern19       ),
                .bist_pattern20      (bist_pattern20       ),
                .bist_pattern21      (bist_pattern21       ),
                .bist_pattern22      (bist_pattern22       ),
                .bist_pattern23      (bist_pattern23       ),
                .bist_pattern24      (bist_pattern24       ),
                .bist_pattern25      (bist_pattern25       ),
                .bist_pattern26      (bist_pattern26       ),
                .bist_pattern27      (bist_pattern27       ),
                .bist_pattern28      (bist_pattern28       ),
                .bist_pattern29      (bist_pattern29       ),
                .bist_pattern30      (bist_pattern30       ),
                .bist_pattern31      (bist_pattern31       ),
                .bist_pattern32      (bist_pattern32       ),
                .bist_pattern33      (bist_pattern33       ),
                .bist_pattern34      (bist_pattern34       ),
                .bist_pattern35      (bist_pattern35       ),
                .bist_pattern36      (bist_pattern36       ),
                .bist_pattern37      (bist_pattern37       ),
                .bist_pattern38      (bist_pattern38       ),
                .bist_pattern39      (bist_pattern39       ),
                .bist_pattern40      (bist_pattern40       ),
                .bist_pattern41      (bist_pattern41       ),
                .bist_pattern42      (bist_pattern42       ),
                .bist_pattern43      (bist_pattern43       ),
                .bist_pattern44      (bist_pattern44       ),
                .bist_pattern45      (bist_pattern45       ),
                .bist_pattern46      (bist_pattern46       ),
                .bist_pattern47      (bist_pattern47       ),
                .bist_pattern48      (bist_pattern48       ),
                .bist_pattern49      (bist_pattern49       ),
                .bist_pattern50      (bist_pattern50       ),
                .bist_pattern51      (bist_pattern51       ),
                .bist_pattern52      (bist_pattern52       ),
                .bist_pattern53      (bist_pattern53       ),
                .bist_pattern54      (bist_pattern54       ),
                .bist_pattern55      (bist_pattern55       ),
                .bist_pattern56      (bist_pattern56       ),
                .bist_pattern57      (bist_pattern57       ),
                .bist_pattern58      (bist_pattern58       ),
                .bist_pattern59      (bist_pattern59       ),
                .bist_pattern60      (bist_pattern60       ),
                .bist_pattern61      (bist_pattern61       ),
                .bist_pattern62      (bist_pattern62       ),
                .bist_pattern63      (bist_pattern63       ),
                .bist_csl_scan_num   (bist_csl_scan_num    ),
                .bist_wl_scan_num    (bist_wl_scan_num     ),
                .csl_err_threshold   (csl_err_threshold    ),
                .bank_success        (bank_success         ),
                .bist_wl_scan_single_pattern_rd_num(bist_wl_scan_single_pattern_rd_num),
                
                .mc_timeout_th       (mc_timeout_th        ),
                
                .bnksel_n            (bnksel_n             ), 
                .gradd_n             (gradd_n              ),
                .gcas_wr             (gcas_wr              ),
                .gcas_rd             (gcas_rd              ),
                .gcadd               (gcadd                ),
                //.wrrdy_n             (wrrdy_n              ),
                .wdl                 (wdl                  ),
                .wdl_oe              (wdl_oe               ),
                .rdrdy_n             (rdrdy_n              ),
                .rdl                 (rdl                  ),
                
                .hub_frame_vld       (mc_frame_vld         ),
                .hub_frame_rdy       (mc_frame_rdy         ),
                .hub_frame_data      (mc_frame_data        ),
                
                .mc_rvalid           (mc_back_rvalid       ),
                .mc_rdata            (mc_back_rdata        ),
                
                .bank_radd_set_time  (bank_radd_set_time_o ),
                .cadd_set_time       (cadd_set_time_o      ),
                .r_cas_set_time      (r_cas_set_time_o     ),
                .w_cas_set_time      (w_cas_set_time_o     ),
                .cas_wrrdy_time      (cas_wrrdy_time_o     ),
                
                .hang_timeout_intr   (mc_timeout_intr      ),
                .monitor_signals     (monitor_signals      ),
                //rf 
                .mc_rf_start_sel     (mc_rf_start_sel      ),
                .rf_start_time       (rf_start_time        ),
                .rf_period           (rf_period            ),
                .rf_period_up_en     (rf_period_up_en      ),
                .mc_rf_period_sel    (mc_rf_period_sel     ),

                .soc_apb_pslverr     (soc_apb_pslverr      ),
                .pe_apb_pslverr      (pe_apb_pslverr       )



    );










endmodule
