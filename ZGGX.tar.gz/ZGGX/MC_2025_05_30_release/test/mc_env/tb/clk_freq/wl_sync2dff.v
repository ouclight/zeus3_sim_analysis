/*********************************-Verilog-****************************************
-- All rights reserved.
-- Copyright (c) 2018 -        Xi'an UniIC
**********************************************************************************
-- Project         :   WORKLIBRARY
-- Filename        :   wl_sync2dff.v
-- Language        :   Verilog
-- Author          :   Han Yang
-- Create Date     :   2019-07-12
**********************************************************************************
-- Abstract        :   (you need type related info here manually)
-- Description     :
--                                       .
--                     (you need type related info here manually)
**********************************************************************************
-- History:
-- Date (y-m-d)       Versions          Author            Description
-- 2019-07-12          1.0              hanyang           initial version
--
**********************************************************************************/
module   wl_sync2dff
     (
     clk        ,
     rst_n      ,
     din        ,
     dout       
     );
//---------------------------------------------------------------------------------------
//defines / params
//---------------------------------------------------------------------------------------
parameter WIDTH = 1;//width
parameter SYNC_TYPE = 2;//sync stage

//---------------------------------------------------------------------------------------
//port list
//---------------------------------------------------------------------------------------
input                                   clk     ;//sys clk
input                                   rst_n   ;//rst
input       [WIDTH-1:0]                 din     ;
output      [WIDTH-1:0]                 dout    ;

//---------------------------------------------------------------------------------------
//process signal
//---------------------------------------------------------------------------------------
reg     [WIDTH-1:0]     data_d1;
reg     [WIDTH-1:0]     data_d2;

integer                 i;

//---------------------------------------------------------------------------------------
//code start
//---------------------------------------------------------------------------------------
//`ifdef RTLSIM
//always @ (posedge clk or negedge rst_n)
//    if(!rst_n)
//        begin
//            data_d1 <= {WIDTH{1'b0}};
//            data_d2 <= {WIDTH{1'b0}};
//        end
//    else
//        begin
//            data_d1 <= din;
//            data_d2 <= data_d1;
//        end
//assign  dout = data_d2;
//`else
DW_sync 
    #(
     .width         (WIDTH          ),
     .f_sync_type   (SYNC_TYPE      ),
     .tst_mode      (0              ),
     .verif_en      (1              )
     )
DW_sync_u 
    ( 
    .clk_d          (clk            ),
    .rst_d_n        (rst_n          ),
    .init_d_n       (1'b1           ),
    .data_s         (din            ),
    .test           (1'b0           ),
    .data_d         (dout           )
    );
//`endif
//---------------------------------------------------------------------------------------
//code end
//---------------------------------------------------------------------------------------
endmodule
