/*********************************-Verilog-****************************************
-- All rights reserved.
-- Copyright (c) 2018 -        Xi'an UniIC
**********************************************************************************
-- Project         :   Common
-- Filename        :   ecc_encode
-- Language        :   Verilog
-- Author          :   Han Yang
-- Create Date     :   2022-10-18
**********************************************************************************
-- Abstract        :   (you need type related info here manually)
-- Description     :
--                                       .
--                     (you need type related info here manually)
**********************************************************************************
-- History:
-- Date (y-m-d)       Versions          Author            Description
-- 2022-10-18          1.0              hanyang           initial version
--
**********************************************************************************/
module  ecc_encode_aux
        (
        //input
        i_data                      ,
        i_ecc_on                    ,
        //output
        o_data                       
        );
//-----------------------------------------------------------------------------------------
//parameters
//-----------------------------------------------------------------------------------------
//correction of all single-bit errors
//DATA_WIDTH     CHKBITS
//4    to 11        5
//12   to 26        6
//27   to 57        7
//58   to 120       8
//121  to 247       9
//248  to 502       10
//503  to 1013      11
//1014 to 2036      12
//2037 to 4083      13
//4084 to 8178      14
parameter   DATA_WIDTH      = 128;
parameter   CHK_WIDTH       = 9;

//-----------------------------------------------------------------------------------------
//port list
//-----------------------------------------------------------------------------------------
input       [DATA_WIDTH-1               :0]     i_data                      ;
input                                           i_ecc_on                    ;
output      [DATA_WIDTH+CHK_WIDTH-1     :0]     o_data                      ;

//---------------------------------------------------------------------------------------
//process signal
//---------------------------------------------------------------------------------------
wire        [DATA_WIDTH-1               :0]     s_data                      ;
wire        [CHK_WIDTH-1                :0]     s_chkbit                    ;

//---------------------------------------------------------------------------------------
//code start
//---------------------------------------------------------------------------------------
DW_ecc
    #(
    .width          (DATA_WIDTH         ),
    .chkbits        (CHK_WIDTH          ),
    .synd_sel       (0                  )
    )
DW_ecc_encode
    (
    .gen            (1'b1               ),
    .correct_n      (1'b1               ),
    .datain         (i_data             ),
    .chkin          ({CHK_WIDTH{1'b0}}  ),
    .err_detect     (                   ),
    .err_multpl     (                   ),
    .dataout        (s_data             ),
    .chkout         (s_chkbit           )
    );

assign  o_data = i_ecc_on ? {s_chkbit,s_data} : {{CHK_WIDTH{1'b0}},i_data};

//---------------------------------------------------------------------------------------
//code end
//---------------------------------------------------------------------------------------
endmodule
